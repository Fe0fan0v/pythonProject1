import os
import pygame
import pygame_gui

def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname).convert()
    except pygame.error as message:
        print('Такого файла не существует')
        raise SystemExit(message)
    if color_key is not None:
        color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image

clock = pygame.time.Clock()

def main():
    pygame.init()
    time_delta = clock.tick(60) / 1000.0
    size = 1920, 1080
    pygame.display.set_caption('Main_wind')
    screen = pygame.display.set_mode(size)

    def images():
        global bg, all_sprites
        bg = pygame.image.load("bg.png")
        all_sprites = pygame.sprite.Group()
        ng_image = load_image('ng.png')
        ct_image = load_image('ct.png')
        ex_image = load_image('ex.png')
        ng = pygame.sprite.Sprite(all_sprites)
        ct = pygame.sprite.Sprite(all_sprites)
        ex = pygame.sprite.Sprite(all_sprites)
        ng.image = ng_image
        ct.image = ct_image
        ex.image = ex_image
        ng.rect = ng.image.get_rect()
        ng.rect.topleft = 775, 325
        ct.rect = ct.image.get_rect()
        ct.rect.topleft = 775, 450
        ex.rect = ex.image.get_rect()
        ex.rect.topleft = 775, 575

    images()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            key = pygame.key.get_pressed()
            if key[pygame.K_ESCAPE]:
                running = False
        manager = pygame_gui.ui_manager.UIManager(size)
        manager.process_events(event)
        manager.update(time_delta)
        screen.blit(bg, (0, 0))
        manager.draw_ui(screen)
        all_sprites.draw(screen)
        pygame.display.flip()
    pygame.quit()

main()